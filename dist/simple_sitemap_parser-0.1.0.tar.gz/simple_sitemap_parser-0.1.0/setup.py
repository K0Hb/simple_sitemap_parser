# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['parser']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'simple-sitemap-parser',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Vjacheslav',
    'author_email': 'goplit2010.konovalov@yandex.ru',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
